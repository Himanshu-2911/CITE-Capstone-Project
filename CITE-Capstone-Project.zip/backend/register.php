<?php
$servername = "localhost";
$username = "root";
$password = "159951";
$dbname = "DB1";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$name = htmlspecialchars($_POST['name']);
$email = htmlspecialchars($_POST['email']);
$phone = htmlspecialchars($_POST['phone']);
$course = htmlspecialchars($_POST['course']);

$stmt = $conn->prepare("INSERT INTO thecite (name, email, phone, course) VALUES (?, ?, ?, ?)");
$stmt->bind_param("ssss", $name, $email, $phone, $course);

if ($stmt->execute()) {
    echo "Thank you for registering!";
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>